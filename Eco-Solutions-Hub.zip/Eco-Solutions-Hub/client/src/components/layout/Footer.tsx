import Logo from "@assets/Riddhi_(1)_1770115189941.png";

export function Footer() {
  return (
    <footer className="bg-gray-50 border-t border-gray-100 py-12">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div className="col-span-1 md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
               <div className="w-10 h-10 rounded-full border border-gray-200 overflow-hidden bg-white p-1">
                 <img src={Logo} alt="Logo" className="w-full h-full object-contain" />
               </div>
               <span className="font-serif font-bold text-lg">Riddhi Consultants</span>
            </div>
            <p className="text-sm text-muted-foreground">
              From Testing & Certification to Compliance & Consultancy — We Handle It All.
            </p>
          </div>
          
          <div>
            <h4 className="font-bold mb-4">Services</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>Environmental Testing</li>
              <li>Food Testing</li>
              <li>Regulatory Compliance</li>
              <li>Lab Consultancy</li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="#home" className="hover:text-primary">Home</a></li>
              <li><a href="#about" className="hover:text-primary">About Us</a></li>
              <li><a href="#services" className="hover:text-primary">Services</a></li>
              <li><a href="#contact" className="hover:text-primary">Contact</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-4">Legal</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>Privacy Policy</li>
              <li>Terms of Service</li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-200 pt-8 text-center text-sm text-muted-foreground">
          © {new Date().getFullYear()} Riddhi Consultants. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
