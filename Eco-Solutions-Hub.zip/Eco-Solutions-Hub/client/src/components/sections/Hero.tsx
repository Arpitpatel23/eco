import { ArrowRight, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import heroBg from "@/assets/hero-bg.png";

export function Hero() {
  return (
    <section id="home" className="relative min-h-[90vh] flex items-center pt-20 overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src={heroBg} 
          alt="Laboratory Background" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-white/95 via-white/80 to-transparent dark:from-background/95 dark:to-transparent/50" />
      </div>

      <div className="container mx-auto px-6 relative z-10 grid md:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="max-w-2xl"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-semibold mb-6">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
            </span>
            Reliable. Accurate. Compliant.
          </div>
          
          <h1 className="text-4xl md:text-6xl font-serif font-bold text-foreground leading-tight mb-6">
            We Deliver Solutions <br/>
            <span className="text-primary">For Your Problems</span>
          </h1>
          
          <p className="text-lg md:text-xl text-muted-foreground mb-8 leading-relaxed max-w-lg">
            Riddhi Consultants provides analytical, inspection, testing, and compliance support to industries through scientific, data-driven solutions.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <Button size="lg" className="rounded-full text-base px-8 py-6 shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/30 transition-all" onClick={() => document.getElementById("services")?.scrollIntoView({ behavior: "smooth" })}>
              Explore Services
            </Button>
            <Button size="lg" variant="outline" className="rounded-full text-base px-8 py-6 border-2" onClick={() => document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })}>
              Contact Us <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </div>
          
          <div className="mt-12 flex flex-wrap items-center gap-6 text-sm font-medium text-primary/80">
            <span className="px-3 py-1 bg-primary/5 rounded-md border border-primary/10">Environmental Testing</span>
            <span className="px-3 py-1 bg-primary/5 rounded-md border border-primary/10">Food Testing</span>
            <span className="px-3 py-1 bg-primary/5 rounded-md border border-primary/10">Compliance & Audit</span>
            <span className="px-3 py-1 bg-primary/5 rounded-md border border-primary/10">Lab Consultancy</span>
          </div>

          <div className="mt-8 flex items-center gap-8 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-primary" />
              <span>NABL Guidance</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-primary" />
              <span>Quick Turnaround</span>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
