import { motion } from "framer-motion";
import { CheckCircle } from "lucide-react";

export function About() {
  const reasons = [
    "Reliable, data-driven results",
    "Compliance-focused approach",
    "Quick turnaround time",
    "Customized consultancy solutions",
    "Experienced technical network",
    "End-to-end project coordination"
  ];

  return (
    <section id="about" className="py-24 bg-white relative overflow-hidden">
      {/* Decorative element */}
      <div className="absolute top-0 right-0 w-1/3 h-full bg-secondary/30 skew-x-12 translate-x-1/2 z-0" />

      <div className="container mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-primary font-bold tracking-wide uppercase text-sm mb-3">Who We Are</h2>
            <h3 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-6">
              Your Partner in Quality & Compliance
            </h3>
            <p className="text-lg text-muted-foreground leading-relaxed mb-6">
              Riddhi Consultants provides analytical, inspection, testing, and compliance support to industries, laboratories, MSMEs, and exporters through scientific, process-driven solutions.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed mb-8">
              We bridge the gap between regulatory requirements and operational efficiency, ensuring your business stays compliant while focusing on growth.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="bg-card border border-border rounded-2xl p-8 shadow-xl"
          >
            <h4 className="text-2xl font-serif font-bold mb-6">Why Choose Us?</h4>
            <div className="grid sm:grid-cols-2 gap-4">
              {reasons.map((reason, i) => (
                <div key={i} className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                  <span className="text-muted-foreground font-medium">{reason}</span>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
