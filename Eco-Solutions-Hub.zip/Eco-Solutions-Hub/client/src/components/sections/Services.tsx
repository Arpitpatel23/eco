import { 
  Leaf, 
  FlaskConical, 
  FileCheck, 
  Factory, 
  UtensilsCrossed, 
  Building2, 
  Microscope,
  ShieldCheck
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { motion } from "framer-motion";

const services = [
  {
    category: "Environmental",
    icon: Leaf,
    items: [
      "Ambient Air Monitoring",
      "Stack Emission Monitoring",
      "Water / Waste Water Testing",
      "Noise & Illumination Monitoring"
    ]
  },
  {
    category: "Food & Safety",
    icon: UtensilsCrossed,
    items: [
      "Food / Raw Material Testing",
      "Nutritional Analysis & Labelling",
      "Microbiological Testing",
      "Contamination Checks"
    ]
  },
  {
    category: "Regulatory & Compliance",
    icon: FileCheck,
    items: [
      "FSSAI Registration & Licensing",
      "Environmental Audit & Compliance",
      "Pollution Control Board Approvals",
      "Consent to Establish / Operate"
    ]
  },
  {
    category: "Lab Consultancy",
    icon: Microscope,
    items: [
      "Lab Setup & NABL Guidance",
      "Documentation Support",
      "End-to-End Project Coordination",
      "Inspection Services"
    ]
  }
];

export function Services() {
  return (
    <section id="services" className="py-24 bg-muted/30">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-primary font-bold tracking-wide uppercase text-sm mb-3">Our Expertise</h2>
          <h3 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-6">Comprehensive Testing & Compliance Services</h3>
          <p className="text-muted-foreground text-lg">
            From environmental monitoring to food safety and laboratory setup, we provide end-to-end solutions tailored to your industry needs.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <motion.div
              key={service.category}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
            >
              <Card className="h-full border-none shadow-sm hover:shadow-lg transition-shadow duration-300 group">
                <CardHeader>
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary mb-4 group-hover:bg-primary group-hover:text-white transition-colors duration-300">
                    <service.icon className="w-6 h-6" />
                  </div>
                  <CardTitle className="text-xl font-bold">{service.category}</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {service.items.map((item) => (
                      <li key={item} className="flex items-start gap-2 text-sm text-muted-foreground">
                        <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-primary/60 shrink-0" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
