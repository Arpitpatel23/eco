import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { MapPin, Phone, Mail, Clock } from "lucide-react";

export function Contact() {
  return (
    <section id="contact" className="py-24 bg-foreground text-white relative">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-12">
          
          <div>
            <h2 className="text-primary-foreground/80 font-bold tracking-wide uppercase text-sm mb-3">Get in Touch</h2>
            <h3 className="text-3xl md:text-4xl font-serif font-bold text-white mb-6">
              Ready to start your project?
            </h3>
            <p className="text-gray-300 text-lg mb-12 max-w-md">
              Contact us for quotes, consultancy, or any inquiries regarding our testing and compliance services.
            </p>

            <div className="space-y-8">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center text-primary-foreground shrink-0">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <h5 className="font-semibold text-white mb-1">Call Us</h5>
                  <p className="text-gray-300">+91 8839054006</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center text-primary-foreground shrink-0">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <h5 className="font-semibold text-white mb-1">Email Us</h5>
                  <p className="text-gray-300">Sales@riddhiconsultant.com</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center text-primary-foreground shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h5 className="font-semibold text-white mb-1">Location</h5>
                  <p className="text-gray-300">Indore (Madhya Pradesh)</p>
                </div>
              </div>
            </div>
          </div>

          <Card className="bg-white text-foreground border-none shadow-2xl">
            <CardContent className="p-8">
              <h4 className="text-2xl font-serif font-bold mb-6">Send us a message</h4>
              <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">First Name</label>
                    <Input placeholder="John" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Last Name</label>
                    <Input placeholder="Doe" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Email</label>
                  <Input type="email" placeholder="john@company.com" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Service Interest</label>
                  <Input placeholder="e.g. Environmental Testing" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Message</label>
                  <Textarea placeholder="Tell us about your requirements..." className="min-h-[120px]" />
                </div>
                <Button type="submit" className="w-full text-base py-6 bg-primary hover:bg-primary/90">
                  Send Message
                </Button>
              </form>
            </CardContent>
          </Card>

        </div>
      </div>
    </section>
  );
}
